# horizon-lab

Companion code for the article **"The Line That Eats Every Job: What One AI Chart Says About the Next Five Years."**

It takes METR's published "time horizon" data (the human task length an AI can
complete at 50% reliability), fits the exponential trend, and extrapolates it to
project when AI crosses each length of human work: an hour, a workday, a week, a
month, a year.

> **What this is.** A transparent replot and extrapolation of real published data,
> with honest bootstrap uncertainty. The extrapolation is the author's; trends bend.

## Quick start

```bash
pip install -r requirements.txt
python -m hlab.experiment      # fit, project, bootstrap -> results/horizon.json
python viz/make_figures.py     # the charts
python viz/make_gif.py         # the animation
python viz/cover.py            # the cover
```

## Layout

```
hlab/
  data.py        the real METR data points + the exponential model
  experiment.py  fit, extrapolate, bootstrap uncertainty
viz/
  style.py, make_figures.py, make_gif.py, cover.py
```

## Headline results (from this code)

| Milestone | Projected year (7-mo trend) |
|---|---|
| 1 hour of autonomous work | early 2025 (already crossed) |
| 1 workday (8h) | ~mid-late 2026 |
| 1 workweek (40h) | ~2027 |
| 1 month (160h) | ~2028 |
| 1 work-year (2000h) | ~2030 |

Fitted doubling time: ~6.4 months (R2 = 0.97), matching METR's ~7-month headline.

## License

Code: MIT. METR data belongs to METR (metr.org), used here with attribution.

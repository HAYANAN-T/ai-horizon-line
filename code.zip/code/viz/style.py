"""A small, consistent light-theme design system for every figure."""
from __future__ import annotations
import pathlib
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import FancyBboxPatch

ROOT = pathlib.Path(__file__).resolve().parents[1]
for f in (ROOT / "fonts").glob("*.otf"):
    font_manager.fontManager.addfont(str(f))

# ---- tokens --------------------------------------------------------------
BG = "#EEF2F7"        # page behind the card
CARD = "#FFFFFF"
INK = "#152033"
SUB = "#5A6679"
FAINT = "#98A2B3"
GRID = "#E7EBF1"
RULE = "#D8DEE7"

RESTRAINED = "#2563C9"
AGGRESSIVE = "#D6453D"
PASSIVE = "#D9921A"
MIXED = "#7A4CC2"
GOOD = "#1E9A6A"
NEUTRAL = "#A3ADBB"

WORLD_COLORS = {"restrained": RESTRAINED, "aggressive": AGGRESSIVE,
                "passive": PASSIVE, "mixed": MIXED}
WORLD_LABELS = {"restrained": "Restrained world", "aggressive": "Aggressive world",
                "passive": "Passive world", "mixed": "Mixed world"}

FONT = "IBM Plex Sans"

mpl.rcParams.update({
    "font.family": FONT,
    "font.size": 10.5,
    "axes.edgecolor": RULE,
    "axes.labelcolor": SUB,
    "axes.labelsize": 10.5,
    "axes.titlesize": 12,
    "axes.titleweight": "semibold",
    "axes.titlecolor": INK,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "grid.color": GRID,
    "grid.linewidth": 0.9,
    "xtick.color": SUB,
    "ytick.color": SUB,
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "xtick.major.size": 0,
    "ytick.major.size": 0,
    "legend.frameon": False,
    "legend.fontsize": 9.5,
    "savefig.dpi": 200,
    "figure.dpi": 100,
})


def card(w=8.0, h=4.8, title="", subtitle="", source="", top=0.80, bottom=0.14,
         left=0.085, right=0.965):
    """A white rounded card on a soft page. Returns (fig, gridspec-kwargs)."""
    fig = plt.figure(figsize=(w, h), facecolor=BG)
    pad = 0.018
    fig.patches.append(FancyBboxPatch(
        (pad, pad * w / h), 1 - 2 * pad, 1 - 2 * pad * w / h,
        boxstyle="round,pad=0,rounding_size=0.018", transform=fig.transFigure,
        facecolor=CARD, edgecolor=RULE, linewidth=0.8, zorder=-10))
    if title:
        fig.text(left, 0.915, title, fontsize=15.5, fontweight="semibold", color=INK,
                 ha="left", va="center")
    if subtitle:
        fig.text(left, 0.855, subtitle, fontsize=10.5, color=SUB, ha="left", va="center")
    if source:
        fig.text(left, 0.055, source, fontsize=8.5, color=FAINT, ha="left", va="center")
    return fig, dict(left=left, right=right, top=top, bottom=bottom)


def style_ax(ax, xlabel="", ylabel="", ygrid_only=True):
    ax.set_facecolor(CARD)
    if ygrid_only:
        ax.grid(axis="x", visible=False)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.spines["left"].set_visible(False)
    ax.tick_params(axis="both", pad=6)
    return ax


def panel_title(ax, text, sub=None):
    ax.text(0, 1.10 if sub else 1.05, text, transform=ax.transAxes, fontsize=11.5, fontweight="semibold",
            color=INK, ha="left", va="bottom")
    if sub:
        ax.text(0, 1.03, sub, transform=ax.transAxes, fontsize=9.3, color=SUB,
                ha="left", va="bottom")


def end_label(ax, x, y, text, color, dy=0, weight="semibold"):
    ax.annotate(text, (x, y), xytext=(8, dy), textcoords="offset points",
                color=color, fontsize=9.5, fontweight=weight, va="center", ha="left",
                annotation_clip=False)


def save(fig, name):
    out = ROOT / "figures" / name
    fig.savefig(out, facecolor=fig.get_facecolor())
    plt.close(fig)
    return out

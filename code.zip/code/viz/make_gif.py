"""Animated: the time-horizon line growing year by year, crossing human-work thresholds."""
import sys, pathlib, json
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from viz.style import *  # noqa
from hlab.data import MODELS, THRESHOLDS
LINE=RESTRAINED; PROJ=MIXED; THRESH=AGGRESSIVE

def yf(d): return d.year + (d.timetuple().tm_yday-1)/365.25

def main():
    j=json.load(open(ROOT/"results/horizon.json")); a,b=j["fit_full"]
    xs=np.array([yf(m[1]) for m in MODELS]); ys=np.array([m[2] for m in MODELS])

    fig=plt.figure(figsize=(8.2,4.8),facecolor=BG,dpi=100)
    fig.text(0.06,0.92,"Watch the line cross your job",fontsize=15,fontweight="semibold",color=INK)
    fig.text(0.06,0.862,"AI's autonomous 'time horizon' growing since 2019, and where the trend points next.",fontsize=9.3,color=SUB)
    fig.text(0.06,0.04,"Source: METR time-horizon data, replotted and extrapolated by the author.",fontsize=8,color=FAINT)
    ax=fig.add_axes([0.13,0.16,0.63,0.66]); ax.set_yscale("log")
    style_ax(ax,"Year","")
    ax.set_xlim(2019,2031); ax.set_ylim(0.02,2000*60*3)
    ax.set_yticks([1,60,8*60,40*60,160*60,2000*60],["1 min","1 hr","1 day","1 wk","1 mo","1 yr"])
    for name,mins in THRESHOLDS:
        ax.axhline(mins,color=THRESH,lw=0.8,alpha=0.35,ls=(0,(2,3)))
    line_hist,=ax.plot([],[],color=LINE,lw=2.4,zorder=4)
    line_proj,=ax.plot([],[],color=PROJ,lw=2.4,ls=(0,(5,3)),zorder=4)
    dot,=ax.plot([],[],"o",color=PROJ,ms=10,markerfacecolor=CARD,mew=2,zorder=6)
    pts=ax.scatter([],[],s=36,color=LINE,edgecolors=CARD,linewidths=1.2,zorder=5)
    cap=fig.text(0.79,0.62,"",fontsize=10,color=INK,fontweight="semibold",va="top")
    reached=fig.text(0.79,0.32,"",fontsize=8.5,color=THRESH,va="top")

    frames=np.linspace(2019,2031,90)
    def human(mins):
        if mins<60: return f"{mins:.0f} min"
        if mins<8*60: return f"{mins/60:.1f} hr"
        if mins<40*60: return f"{mins/60/8:.1f} days"
        if mins<160*60: return f"{mins/60/40:.1f} wks"
        if mins<2000*60: return f"{mins/60/160:.1f} mo"
        return f"{mins/60/2000:.1f} yr"
    def update(t):
        xline=np.linspace(2019,min(t,2031),100)
        yline=2**(a+b*(xline-2019))
        hm=xline<=2026.2
        line_hist.set_data(xline[hm],yline[hm])
        line_proj.set_data(xline[~hm],yline[~hm])
        cur=2**(a+b*(t-2019)); dot.set_data([t],[cur])
        vis=xs<=t
        pts.set_offsets(np.c_[xs[vis],ys[vis]] if vis.any() else np.empty((0,2)))
        cap.set_text(f"year {t:.0f}\n\nAI can do a\n{human(cur)}\njob alone")
        done=[n for n,m in THRESHOLDS if cur>=m]
        reached.set_text(("crossed:\n"+"\n".join(done)) if done else "")
        return line_hist,line_proj,dot,pts,cap,reached
    anim=FuncAnimation(fig,update,frames=frames,blit=False)
    out=ROOT/"figures/anim_horizon.gif"
    anim.save(out,writer=PillowWriter(fps=10),savefig_kwargs={"facecolor":BG})
    print(out)

if __name__=="__main__":
    main()

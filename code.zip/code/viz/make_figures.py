"""Figures for the AI time-horizon article, on the shared light theme."""
import json, sys, pathlib
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
from datetime import date

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from viz.style import *  # noqa
from hlab.data import MODELS, THRESHOLDS, _to_years, EPOCH

R = ROOT / "results"
LINE = RESTRAINED
PROJ = MIXED
THRESH = AGGRESSIVE


def _yf(d):
    return d.year + (d.timetuple().tm_yday - 1) / 365.25


def fig_main():
    j = json.load(open(R / "horizon.json"))
    a, b = j["fit_full"]
    fig, gs = card(9.6, 5.6,
                   "The exponential that should be on every screen",
                   "The human task length AI can finish at 50% reliability has doubled every ~7 months for six years. "
                   "Extend the line, and the next few years look wild.",
                   "Source: METR Time Horizon 1.0/1.1 (2026), replotted by the author. Extrapolation is the author's; "
                   "trends can and do bend.",
                   top=0.74, bottom=0.13, left=0.09, right=0.79)
    ax = style_ax(fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0]), "Model release year", "")
    ax.set_yscale("log")

    # data points
    xs = np.array([_yf(m[1]) for m in MODELS])
    ys = np.array([m[2] for m in MODELS])
    ax.scatter(xs, ys, s=42, color=LINE, edgecolors=CARD, linewidths=1.4, zorder=5)
    # label a few key models
    for m in MODELS:
        if m[0] in ("GPT-2", "GPT-4 (0314)", "GPT-5", "Claude Opus 4.6"):
            ax.annotate(m[0], (_yf(m[1]), m[2]), textcoords="offset points", xytext=(6, -2),
                        fontsize=7.6, color=SUB)

    # fitted + projected line
    xline = np.linspace(2019, 2031, 200)
    yline = 2 ** (a + b * (xline - 2019))
    fit_mask = xline <= 2026.2
    ax.plot(xline[fit_mask], yline[fit_mask], color=LINE, lw=2.2, zorder=4)
    ax.plot(xline[~fit_mask], yline[~fit_mask], color=PROJ, lw=2.2, ls=(0, (5, 3)), zorder=4)
    ax.text(2029.3, 2 ** (a + b * (2029.3 - 2019)) * 0.3, "extrapolation", color=PROJ,
            fontsize=9, fontweight="semibold", rotation=38)

    # threshold lines
    for name, mins in THRESHOLDS:
        ax.axhline(mins, color=THRESH, lw=0.8, alpha=0.4, ls=(0, (2, 3)))
        ax.text(2019.1, mins * 1.15, name, fontsize=7.8, color=THRESH)
    ax.set_ylim(0.02, 2000 * 60 * 3)
    ax.set_xlim(2019, 2031)
    ax.set_yticks([1, 60, 8*60, 40*60, 160*60, 2000*60],
                  ["1 min", "1 hr", "1 day", "1 wk", "1 mo", "1 yr"])
    ax.set_xticks([2019, 2021, 2023, 2025, 2027, 2029, 2031])

    # doubling annotation
    ax.text(0.03, 0.93, f"doubling every {j['doubling_full_days']/30.4:.1f} months   (R2 = {j['r2_full']:.2f})",
            transform=ax.transAxes, fontsize=9.5, color=INK, fontweight="semibold",
            bbox=dict(boxstyle="round,pad=0.4", fc="#EEF3FB", ec=LINE, lw=1))
    return save(fig, "horizon_main.png")


def fig_staircase():
    j = json.load(open(R / "horizon.json"))
    fig, gs = card(9.2, 5.0,
                   "When AI can do your workday, your week, your month",
                   "The year the trend says AI crosses each length of human work, at 50% reliability. Bars show "
                   "the bootstrap 10-90% range.",
                   "Source: author's extrapolation of METR time-horizon data. Uncertainty from bootstrap resampling.",
                   top=0.74, bottom=0.17, left=0.20, right=0.94)
    ax = style_ax(fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0]), "Projected year AI reaches this", "")
    ax.grid(axis="y", visible=False); ax.grid(axis="x", visible=True)
    ts = j["thresholds"]
    y = np.arange(len(ts))[::-1]
    meds = [t["boot_median"] for t in ts]
    los = [t["boot_lo"] for t in ts]
    his = [t["boot_hi"] for t in ts]
    cols = [GOOD, RESTRAINED, PASSIVE, MIXED, AGGRESSIVE]
    for yy, t, lo, hi, med, c in zip(y, ts, los, his, meds, cols):
        ax.plot([lo, hi], [yy, yy], color=c, lw=7, alpha=0.28, solid_capstyle="round", zorder=2)
        ax.plot([med], [yy], "o", color=c, ms=11, zorder=4)
        ax.annotate(f"{int(round(med))}", (med, yy), textcoords="offset points", xytext=(0, 11),
                    ha="center", fontsize=10, fontweight="semibold", color=INK)
    ax.set_yticks(y, [t["name"] for t in ts])
    ax.tick_params(axis="y", labelsize=10.5, labelcolor=INK)
    ax.set_xlim(2024.5, 2031.5); ax.set_ylim(-0.6, len(ts) - 0.4)
    ax.set_xticks([2025, 2026, 2027, 2028, 2029, 2030, 2031])
    return save(fig, "staircase.png")


def fig_regimes():
    j = json.load(open(R / "horizon.json"))
    fig, gs = card(9.2, 4.6,
                   "How fast is the clock really ticking?",
                   "The doubling time depends on which slice of history you trust. All three tell the same "
                   "qualitative story, faster than almost anyone planned for.",
                   "Source: METR Time Horizon 1.1 (2026). Bars are the author's fits to METR data.",
                   top=0.76, bottom=0.15, left=0.09, right=0.72)
    ax = style_ax(fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0]), "Doubling time (months)", "")
    ax.grid(axis="y", visible=False); ax.grid(axis="x", visible=True)
    regimes = [("Full 2019-2026", j["doubling_full_days"]/30.4, RESTRAINED, "the steady headline"),
               ("Since 2023", j["doubling_2023_days"]/30.4, PASSIVE, "faster"),
               ("Since 2024", j["doubling_2024_days"]/30.4, AGGRESSIVE, "fastest")]
    y = np.arange(len(regimes))[::-1]
    for yy, (name, val, col, note) in zip(y, regimes):
        ax.barh(yy, val, height=0.55, color=col, zorder=3)
        ax.text(val + 0.15, yy, f"{val:.1f} mo  ({note})", va="center", fontsize=9.5,
                color=col, fontweight="semibold")
    ax.set_yticks(y, [r[0] for r in regimes]); ax.tick_params(axis="y", labelsize=10, labelcolor=INK)
    ax.set_xlim(0, 9)
    return save(fig, "regimes.png")


def fig_concept():
    fig, gs = card(9.2, 4.2,
                   "What 'time horizon' actually measures",
                   "Not how smart the AI sounds. How long a job it can finish on its own before it needs you.",
                   "Original diagram by the author, illustrating METR's time-horizon metric.",
                   top=0.80, bottom=0.10, left=0.05, right=0.95)
    ax = fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0])
    ax.set_xlim(0, 12); ax.set_ylim(0, 4.5); ax.axis("off")
    tasks = [("seconds", "answer a question", 0.6, GOOD),
             ("minutes", "fix a small bug", 1.8, RESTRAINED),
             ("hours", "build a feature", 4.0, PASSIVE),
             ("days", "ship a project", 7.2, MIXED),
             ("weeks+", "run research alone", 10.4, AGGRESSIVE)]
    for label, what, x, col in tasks:
        h = 0.5 + {"seconds":0.2,"minutes":0.7,"hours":1.4,"days":2.2,"weeks+":3.0}[label]
        ax.add_patch(FancyBboxPatch((x-0.7, 0.4), 1.4, h, boxstyle="round,pad=0,rounding_size=0.06",
                                    fc=col, alpha=0.15, ec=col, lw=1.4))
        ax.text(x, 0.4+h+0.18, label, ha="center", fontsize=9.5, fontweight="semibold", color=col)
        ax.text(x, 0.62, what, ha="center", fontsize=7.6, color=SUB, rotation=0)
    ax.annotate("", xy=(11.2, 0.4), xytext=(0.5, 0.4), arrowprops=dict(arrowstyle="-|>", color=FAINT, lw=1.4))
    ax.text(0.5, 4.05, "longer the AI works unsupervised  ->", fontsize=9, color=SUB)
    return save(fig, "concept_horizon.png")


if __name__ == "__main__":
    for f in [fig_main, fig_staircase, fig_regimes, fig_concept]:
        print(f())

"""Cover: the striking exponential with thresholds, plus title."""
import sys, pathlib, json
import numpy as np
import matplotlib.pyplot as plt
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from viz.style import *  # noqa
from hlab.data import MODELS, THRESHOLDS
LINE=RESTRAINED; PROJ=MIXED; THRESH=AGGRESSIVE
def yf(d): return d.year+(d.timetuple().tm_yday-1)/365.25
def main():
    j=json.load(open(ROOT/"results/horizon.json")); a,b=j["fit_full"]
    fig=plt.figure(figsize=(8,4.5),facecolor="#F3F6FA")
    fig.text(0.06,0.74,"The line that",fontsize=30,fontweight="bold",color=INK,va="center")
    fig.text(0.06,0.635,"eats every job",fontsize=30,fontweight="bold",color=PROJ,va="center")
    fig.text(0.06,0.47,"One AI metric has doubled every 7 months\nfor six years. I extended it, and it says\nyour whole workweek is on the clock",
             fontsize=11,color=SUB,va="center",linespacing=1.5)
    fig.text(0.06,0.14,"Right: AI's autonomous 'time horizon,' real data (blue) and where the\ntrend points (purple).",
             fontsize=7.4,color=FAINT,linespacing=1.4)
    ax=fig.add_axes([0.55,0.14,0.41,0.72]); ax.set_yscale("log")
    ax.set_xlim(2019,2031); ax.set_ylim(0.02,2000*60*3)
    xs=np.array([yf(m[1]) for m in MODELS]); ys=np.array([m[2] for m in MODELS])
    xline=np.linspace(2019,2031,150); yline=2**(a+b*(xline-2019)); hm=xline<=2026.2
    for name,mins in THRESHOLDS: ax.axhline(mins,color=THRESH,lw=0.7,alpha=0.3,ls=(0,(2,3)))
    ax.plot(xline[hm],yline[hm],color=LINE,lw=2.4)
    ax.plot(xline[~hm],yline[~hm],color=PROJ,lw=2.4,ls=(0,(5,3)))
    ax.scatter(xs,ys,s=26,color=LINE,edgecolors="white",linewidths=1,zorder=5)
    ax.set_yticks([60,8*60,40*60,160*60,2000*60],["hr","day","wk","mo","yr"],fontsize=8)
    ax.set_xticks([2019,2023,2027,2031]); ax.tick_params(labelsize=8)
    for s in ax.spines.values(): s.set_edgecolor(RULE)
    ax.grid(False)
    fig.savefig(ROOT/"figures/cover.png",dpi=200,facecolor=fig.get_facecolor())
    print("cover.png")
if __name__=="__main__": main()

"""
E1 - Fit METR's time-horizon trend, extrapolate it, and quantify the uncertainty.

Outputs results/horizon.json with:
  - the fitted doubling times (full, since-2023, since-2024)
  - the projected crossing date for each human-work threshold, under both the
    conservative (7-month) and recent (since-2023) trends
  - a bootstrap distribution over crossing years, so we can draw honest error bars
"""
import json, sys, pathlib
import numpy as np
from datetime import date

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from hlab.data import fit, cross_date, horizon_at, THRESHOLDS, MODELS, _to_years, EPOCH


def year_frac(d: date) -> float:
    return d.year + (d.timetuple().tm_yday - 1) / 365.25


def cross_year(a, b, minutes):
    yrs = (np.log2(minutes) - a) / b
    d = EPOCH.fromordinal(EPOCH.toordinal() + int(yrs * 365.25))
    return year_frac(d)


def main():
    a, b, dbl, r2, xs, ys = fit()
    a2, b2, dbl2, r2b, _, _ = fit(since=date(2023, 1, 1))
    a3, b3, dbl3, r3, _, _ = fit(since=date(2024, 1, 1))

    out = {
        "doubling_full_days": dbl, "r2_full": r2,
        "doubling_2023_days": dbl2, "doubling_2024_days": dbl3,
        "fit_full": [a, b], "fit_2023": [a2, b2],
        "models": [(m[0], m[1].isoformat(), m[2]) for m in MODELS],
        "thresholds": [],
    }

    # bootstrap for uncertainty on the full trend
    rng = np.random.default_rng(0)
    NB = 3000
    boot = {name: [] for name, _ in THRESHOLDS}
    dbls = []
    for _ in range(NB):
        idx = rng.integers(0, len(xs), len(xs))
        bb, aa = np.polyfit(xs[idx], ys[idx], 1)
        dbls.append(365.25 / bb)
        for name, mins in THRESHOLDS:
            boot[name].append(cross_year(aa, bb, mins))

    for name, mins in THRESHOLDS:
        s = np.array(boot[name])
        out["thresholds"].append({
            "name": name, "minutes": mins,
            "cross_slow": cross_year(a, b, mins),
            "cross_fast": cross_year(a2, b2, mins),
            "boot_median": float(np.median(s)),
            "boot_lo": float(np.percentile(s, 10)),
            "boot_hi": float(np.percentile(s, 90)),
        })
    out["boot_doubling_days"] = [float(np.median(dbls)),
                                 float(np.percentile(dbls, 5)),
                                 float(np.percentile(dbls, 95))]

    (ROOT / "results").mkdir(exist_ok=True)
    json.dump(out, open(ROOT / "results/horizon.json", "w"), indent=2)

    print(f"Full trend doubling: {dbl:.0f} days ({dbl/30.4:.1f} mo), R2={r2:.3f}")
    print(f"Since-2023 doubling: {dbl2:.0f} days ({dbl2/30.4:.1f} mo)")
    print(f"Since-2024 doubling: {dbl3:.0f} days ({dbl3/30.4:.1f} mo)")
    for t in out["thresholds"]:
        print(f"  {t['name']:22s}: {t['cross_slow']:.1f} (7-mo) | {t['cross_fast']:.1f} (recent) "
              f"| boot {t['boot_median']:.1f} [{t['boot_lo']:.1f},{t['boot_hi']:.1f}]")


if __name__ == "__main__":
    main()

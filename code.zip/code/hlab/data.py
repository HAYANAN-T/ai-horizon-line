"""
hlab.data - the real METR time-horizon dataset, and the exponential model that
extrapolates it into the future.

Every data point below is METR's published 50%-time-horizon estimate (the human
task length an AI can complete with 50% reliability), in MINUTES, paired with the
model's release date. Sourced from METR's Time Horizon 1.0 and 1.1 releases
(metr.org). We fit log2(horizon) as a linear function of time and read off the
doubling time, exactly as METR does, then project when the horizon crosses the
lengths of real human work: an hour, a workday, a workweek, a month, a year.

This is an extrapolation, not a prophecy. The whole point of the article is to
take the trend literally and see what it implies, while being honest that trends
bend.
"""
from __future__ import annotations
import numpy as np
from datetime import date

# (label, release date, 50%-time-horizon in minutes)
# TH1.0 "stitched" series (2019-2025), the headline ~7-month-doubling dataset.
MODELS = [
    ("GPT-2",            date(2019, 2, 1),   0.05),
    ("GPT-3",            date(2020, 6, 1),   0.15),
    ("GPT-3.5",          date(2022, 3, 1),   0.6),
    ("GPT-4 (0314)",     date(2023, 3, 14),  5.4),
    ("GPT-4 1106",       date(2023, 11, 6),  8.5),
    ("GPT-4o",           date(2024, 5, 13),  9.2),
    ("Claude 3.7 Sonnet",date(2025, 2, 24),  56.0),
    ("o3",               date(2025, 4, 16),  94.0),
    ("Claude Sonnet 4",  date(2025, 5, 22),  75.0),
    ("Grok 4",           date(2025, 7, 9),   109.0),
    ("Claude Opus 4.1",  date(2025, 8, 5),   114.0),
    ("GPT-5",            date(2025, 8, 7),   138.0),
    ("Claude Sonnet 4.5",date(2025, 9, 29),  122.0),
    ("GPT-5.1-codex-max",date(2025, 11, 24), 173.0),
    ("Claude Opus 4.5",  date(2025, 11, 24), 289.0),
    # 2026 frontier points reported around the TH1.1 release / early 2026
    ("Claude Opus 4.6",  date(2026, 2, 10),  718.0),
]

# Human-work reference thresholds, in minutes
THRESHOLDS = [
    ("1 hour", 60),
    ("1 workday (8h)", 8 * 60),
    ("1 workweek (40h)", 40 * 60),
    ("1 month (160h)", 160 * 60),
    ("1 work-year (2000h)", 2000 * 60),
]

EPOCH = date(2019, 1, 1)


def _to_years(d: date) -> float:
    return (d - EPOCH).days / 365.25


def fit(models=MODELS, since: date | None = None):
    """Fit log2(minutes) = a + b * years. Returns (a, b, doubling_days, r2, xs, ys)."""
    pts = [(m[1], m[2]) for m in models if (since is None or m[1] >= since)]
    xs = np.array([_to_years(d) for d, _ in pts])
    ys = np.array([np.log2(v) for _, v in pts])
    b, a = np.polyfit(xs, ys, 1)
    pred = a + b * xs
    r2 = 1 - np.sum((ys - pred) ** 2) / np.sum((ys - ys.mean()) ** 2)
    doubling_days = 365.25 / b
    return a, b, doubling_days, r2, xs, ys


def horizon_at(a, b, d: date) -> float:
    """Predicted 50%-time-horizon in minutes at date d."""
    return 2 ** (a + b * _to_years(d))


def cross_date(a, b, minutes: float) -> date:
    """Date at which the fitted horizon reaches `minutes`."""
    years = (np.log2(minutes) - a) / b
    return EPOCH.fromordinal(EPOCH.toordinal() + int(years * 365.25))
